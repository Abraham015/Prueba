import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;  //Librerias de un servidor HTTP en Java
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigInteger;                //Librerias de un servidor HTTP en Java
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.concurrent.Executors;

public class WebServer {
    private static final String TASK_ENDPOINT = "/task";
    private static final String STATUS_ENDPOINT = "/status"; //Definición de las dos cadenas correspondientes a los 2 end points del servidor "task y status".

    private final int port; //Variable privada para el puerto.
    private HttpServer server; //Variable privada para el servidor HTTP.

    public static void main(String[] args) { 
        int serverPort = 8080;  //Puerto default del servidor.
        if (args.length == 1) {
            serverPort = Integer.parseInt(args[0]); //Se le asigna una variable serverPort 
        }

        WebServer webServer = new WebServer(serverPort); //Instancia un objeto a Web server
        webServer.startServer(); //Ejecucion del método el cual inicializa la configuración del servidor.

        System.out.println("Servidor escuchando en el puerto " + serverPort); //Imprime el puerto que escucha el servidor.
    }

    public WebServer(int port) { //Constructor que recibe como variable el puerto e inicializa la variable privada port.
        this.port = port;
    }

    public void startServer() { //Metodo starServer
        try {
            this.server = HttpServer.create(new InetSocketAddress(port), 0); //Al objeto server se iguala al create y permite crear una instancia de socket tcp vinculada a una ip y al puerto; y el tamaño de lista de solicitudes que se permiten.
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        HttpContext statusContext = server.createContext(STATUS_ENDPOINT); //Representa mapeo entre la identificacion de recursos, una aplicacion y una interfaz under. 
        HttpContext taskContext = server.createContext(TASK_ENDPOINT); //createcontext crea un objeto http context asociado con la ruta relativa asignada.

        statusContext.setHandler(this::handleStatusCheckRequest); //Recibe el metodo que implementa el manejador y vincula un handler. Para vincularlo con el status.
        taskContext.setHandler(this::handleTaskRequest);

        server.setExecutor(Executors.newFixedThreadPool(8)); //Establece un objeto de tipo ejecutor al servidor. Proviendo un pool de 8 hilos.
        server.start(); //Inicio de un servidor en segundo plano en un nuevo hilo.
    }

    private void handleTaskRequest(HttpExchange exchange) throws IOException { //manejador del endpoint, comunicacion entre el cliente y la interfaz.
        if (!exchange.getRequestMethod().equalsIgnoreCase("post")) { //Verificando que sea el método post.
            exchange.close();
            return;
        }

         Headers headers = exchange.getRequestHeaders(); //recuper todos los heders del exchnge mediante una intefaz map
        //que almacena datos en parejas clave-valor

        //si tenemos el header "X-Test" y su valor asociado es "true"
        if (headers.containsKey("X-Test") && headers.get("X-Test").get(0).equalsIgnoreCase("true")) { 
            String dummyResponse = "123\n"; //se genera la respuesta dummy 123
            sendResponse(dummyResponse.getBytes(), exchange);//y se envía
            return;
        }
        //se inicializa el valor para debugmode como falso
        boolean isDebugMode = false;
        //en caso de usarse el header "X-Debug" y darle el valor "true"
        if (headers.containsKey("X-Debug") && headers.get("X-Debug").get(0).equalsIgnoreCase("true")) {
            //se cambia el valor de activación del modo debug a "true"
            //y se mande información de depuración coo respuesta
            isDebugMode = true;
        }
        //se guarda el inicio del tiempo de procesamiento
        long startTime = System.nanoTime();

        byte[] requestBytes = exchange.getRequestBody().readAllBytes();//se obtiene el cuerpo del mensaje en la transacción HTTP, se lee y almacena como bytes
        byte[] responseBytes = calculateResponse(requestBytes); //calculeteResponse realiza la multiplicación de solicitada y almacena el resultado para enviarlo como repuesta
        //se guarda el final del tiempo de procesamiento
        long finishTime = System.nanoTime();
        //Si se cambia el modo debug a verdadero...
        if (isDebugMode) {
            //se calcula el tiempo que tardó en realizarse la operación y se prepara pra enviarse como respuesta
            String debugMessage = String.format("La operación tomó %d nanosegundos", finishTime - startTime);//se resta el tiepo inicial al tiempo final 
            exchange.getResponseHeaders().put("X-Debug-Info", Arrays.asList(debugMessage));// se guarda el header de respuesta X-Debug-Info con el tiempo de procesamiento en el exchange
        }

        sendResponse(responseBytes, exchange); //se envía la respuesta. La operación realizada y el exchange
    }
    //Método encargado de calcular la respuesta
    private byte[] calculateResponse(byte[] requestBytes) {
        String bodyString = new String(requestBytes); //se pasa el argumento en bytes a objeto string
        String[] stringNumbers = bodyString.split(",");//se eliina la coma que separa los números a multiplicar y guardan en un arrego

        BigInteger result = BigInteger.ONE;
        //para cada número
        for (String number : stringNumbers) {
            BigInteger bigInteger = new BigInteger(number); //se convierte a un objeto "BigInteger"
            result = result.multiply(bigInteger); //Se usa el método "multiply" para realizar la multiplicción
        }

        return String.format("El resultado de la multiplicación es %s\n", result).getBytes();//Se prepra un mensaje anunciando la respuesta y retorna su valor en bytes
    }
    //Se busca si el método usado en la transacción HTTP es de tipo get
    private void handleStatusCheckRequest(HttpExchange exchange) throws IOException {
        //si no es de tipo get se cierra exchange
        if (!exchange.getRequestMethod().equalsIgnoreCase("get")) {
            exchange.close();
            return;
        }
        //en caso de ser de tipo get se envía un mensaje del estado del servidor
        String responseMessage = "El servidor está vivo\n";
        sendResponse(responseMessage.getBytes(), exchange);
    }
    //Método para envíar la respuesta
    private void sendResponse(byte[] responseBytes, HttpExchange exchange) throws IOException {
        exchange.sendResponseHeaders(200, responseBytes.length); //se agrega a exhange el status code y longitud de la respuesta
        OutputStream outputStream = exchange.getResponseBody();// se guarda el cuerpo del mensaje
        outputStream.write(responseBytes); //y pasa al stream
        outputStream.flush(); //se limpia
        outputStream.close(); //se cierra el stream
        exchange.close();
    }
}